@objc(GSTPlugin) class GSTPlugin : CDVPlugin {
    @objc(helloNative:)
    func helloNative(command: CDVInvokedUrlCommand) {
        // If plugin result nil, then we should let app crash
        var pluginResult: CDVPluginResult!

        if let message = command.arguments.first as? String {
            let returnMessage = "GSTPlugin hello \(message) from iOS"
            pluginResult = CDVPluginResult(status: CDVCommandStatus_OK, messageAs: returnMessage)
        } else {
            pluginResult = CDVPluginResult (status: CDVCommandStatus_ERROR, messageAs: "Expected one non-empty string argument.")
        }

        commandDelegate.send(pluginResult, callbackId: command.callbackId)
    }
}
