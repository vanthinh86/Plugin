var exec = require('cordova/exec');

exports.helloNative = function (arg0, success, error) {
    exec(success, error, 'GSTPlugin', 'helloNative', [arg0]);
};
